# FlutterUI - Cookies

Code for the screens created with flutter.

Design Credit - https://dribbble.com/shots/6196911-Cookies-app-3/attachments

How do I code this ? - https://youtu.be/5Cq92yQa3Mo

## Screenshots

![Screenshot_20191017-012435](https://user-images.githubusercontent.com/8137504/66954025-34449980-f07d-11e9-95c4-8c1a0938852c.png)
![Screenshot_20191017-012501](https://user-images.githubusercontent.com/8137504/66954027-34449980-f07d-11e9-8e28-1467e0091c78.png)
